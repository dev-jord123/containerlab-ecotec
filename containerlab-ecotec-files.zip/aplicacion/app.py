import os, socket, datetime
from flask import Flask, render_template, jsonify
import pymysql

app = Flask(__name__)

INSTANCIA = os.getenv("INSTANCE_NAME", "desconocida")
DB_HOST   = os.getenv("DB_HOST", "base-datos")
DB_NAME   = os.getenv("DB_NAME", "smartservices")
DB_USER   = os.getenv("DB_USER", "smartuser")
DB_PASS   = os.getenv("DB_PASSWORD", "")

def conectar():
    return pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASS,
                           database=DB_NAME, connect_timeout=3,
                           cursorclass=pymysql.cursors.DictCursor)

@app.route("/")
def inicio():
    estado_bd, visitas, servicios = "SIN CONEXION", 0, []
    try:
        con = conectar()
        with con.cursor() as cur:
            cur.execute("INSERT INTO visitas (instancia) VALUES (%s)", (INSTANCIA,))
            con.commit()
            cur.execute("SELECT COUNT(*) AS total FROM visitas")
            visitas = cur.fetchone()["total"]
            cur.execute("SELECT nombre, descripcion FROM servicios ORDER BY id")
            servicios = cur.fetchall()
        con.close()
        estado_bd = "CONECTADA"
    except Exception as e:
        estado_bd = f"SIN CONEXION ({type(e).__name__})"

    return render_template("index.html",
        plataforma="SmartServices - Laboratorio de Sistemas Inteligentes",
        instancia=INSTANCIA,
        host=socket.gethostname(),
        fecha=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        estado_bd=estado_bd, visitas=visitas, servicios=servicios)

@app.route("/health")
def health():
    return jsonify(estado="ok", instancia=INSTANCIA), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)