#!/usr/bin/env bash
# Informe de estado de la plataforma ContainerLab ECOTEC
set -uo pipefail

PROYECTO="/opt/containerlab-ecotec"
PUERTO=8080
SALIDA="${PROYECTO}/documentacion/evidencias/diagnostico_$(date +%Y%m%d_%H%M%S).txt"

titulo() { echo; echo "===== $* ====="; }

{
  echo "INFORME DE DIAGNOSTICO - CONTAINERLAB ECOTEC"
  echo "Fecha y hora : $(date '+%F %T %Z')"
  echo "Servidor     : $(hostname)"
  echo "Tiempo activo: $(uptime -p)"

  titulo "USO DE MEMORIA"
  free -h

  titulo "USO DE DISCO"
  df -h / /var/lib/docker 2>/dev/null

  titulo "MOTOR DE CONTENEDORES"
  systemctl is-active docker && docker --version

  titulo "ESTADO Y SALUD DE LOS CONTENEDORES"
  docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'

  titulo "CONSUMO DE RECURSOS"
  docker stats --no-stream --format \
    'table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.MemPerc}}'

  titulo "PUERTOS EN ESCUCHA"
  ss -tuln | grep LISTEN

  titulo "PRUEBA HTTP DEL PORTAL"
  for i in 1 2 3 4; do
    CODIGO=$(curl -s -o /dev/null -w '%{http_code}' http://localhost:${PUERTO}/)
    INSTANCIA=$(curl -s http://localhost:${PUERTO}/ | grep -o 'app-[12]' | head -1)
    echo "Peticion $i -> HTTP ${CODIGO} atendida por ${INSTANCIA:-SIN RESPUESTA}"
  done

  titulo "ULTIMOS ERRORES DEL BALANCEADOR"
  docker logs balanceador 2>&1 | grep -iE 'error|failed|refused' | tail -5 \
    || echo 'Sin errores recientes.'

  titulo "ULTIMOS ERRORES DE APP-1"
  docker logs app-1 2>&1 | grep -iE 'error|traceback|exception' | tail -5 \
    || echo 'Sin errores recientes.'

  echo; echo "===== FIN DEL INFORME ====="
} | tee "${SALIDA}"

echo "Informe guardado en: ${SALIDA}"
