#!/usr/bin/env bash
# Respaldo de la plataforma ContainerLab ECOTEC
set -euo pipefail

PROYECTO="/opt/containerlab-ecotec"
DESTINO="/opt/respaldos"
LOG="/var/log/respaldo_plataforma.log"
RETENCION_DIAS=7
FECHA=$(date +%Y%m%d_%H%M%S)
TEMPORAL="/tmp/respaldo_${FECHA}"

set -a; source "${PROYECTO}/.env"; set +a

registrar() { echo "[$(date '+%F %T')] $*" | tee -a "${LOG}"; }

registrar "===== Inicio del respaldo ====="
mkdir -p "${TEMPORAL}" "${DESTINO}"

# 1) Volcado logico de la base de datos
if docker exec base-datos mariadb-dump -u root -p"${DB_ROOT_PASSWORD}" \
      --databases "${DB_NAME}" > "${TEMPORAL}/${DB_NAME}.sql" 2>>"${LOG}"; then
    registrar "Volcado de la base de datos correcto."
else
    registrar "ERROR: fallo el volcado de la base de datos."; exit 1
fi

# 2) Configuracion de la plataforma
cp "${PROYECTO}/compose.yaml"           "${TEMPORAL}/"
cp "${PROYECTO}/balanceador/nginx.conf" "${TEMPORAL}/"
cp "${PROYECTO}/.env.example"           "${TEMPORAL}/"
cp "${PROYECTO}/base-datos/init.sql"    "${TEMPORAL}/"
registrar "Archivos de configuracion copiados."

# 3) Empaquetado con fecha y hora
ARCHIVO="${DESTINO}/respaldo_containerlab_${FECHA}.tar.gz"
tar -czf "${ARCHIVO}" -C "/tmp" "respaldo_${FECHA}"
chmod 640 "${ARCHIVO}"
rm -rf "${TEMPORAL}"
registrar "Respaldo creado: ${ARCHIVO}"

# 4) Rotacion de respaldos antiguos
BORRADOS=$(find "${DESTINO}" -name 'respaldo_containerlab_*.tar.gz' \
            -mtime +${RETENCION_DIAS} -print -delete | wc -l)
registrar "Respaldos eliminados por antiguedad: ${BORRADOS}"
registrar "===== Fin del respaldo ====="
exit 0
