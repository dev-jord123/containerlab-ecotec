CREATE TABLE IF NOT EXISTS servicios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(160) NOT NULL
);

CREATE TABLE IF NOT EXISTS visitas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  instancia VARCHAR(40) NOT NULL,
  momento TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO servicios (nombre, descripcion) VALUES
  ('Laboratorio de Redes',  'Practicas de conectividad y ruteo'),
  ('Laboratorio de Nube',   'Virtualizacion y contenedores'),
  ('Laboratorio de Datos',  'Bases de datos y analitica');